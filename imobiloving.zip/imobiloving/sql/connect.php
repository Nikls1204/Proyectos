<?php

$servername = "sql304.infinityfree.com";//Cambialo si vas a poner el sql en otro host :)
$username = "if0_37046945";
$password = '1204KlozNeol';
$dbname = 'if0_37046945_inmobiliaria';


$conn = new mysqli($servername, $username, $password, $dbname); //así creas una conexión

//Asi verificas la conexión

if($conn->connect_error){
    die("Conexión fallida: ". $conn->connect_error);
}

$conn->set_charset("utf8");

