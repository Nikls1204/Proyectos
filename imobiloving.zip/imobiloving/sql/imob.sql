-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-07-2024 a las 18:47:57
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `imob`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `propietarios`
--

CREATE TABLE `propietarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `contacto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `propietarios`
--

INSERT INTO `propietarios` (`id`, `nombre`, `contacto`) VALUES
(1, 'Propietario 1', 'contacto1@example.com'),
(2, 'Propietario 2', 'contacto2@example.com'),
(3, 'Propietario 3', 'contacto3@example.com'),
(4, 'Propietario 4', 'contacto4@example.com'),
(5, 'Propietario 5', 'contacto5@example.com'),
(6, 'Propietario 6', 'contacto6@example.com'),
(7, 'Propietario 7', 'contacto7@example.com'),
(8, 'Propietario 8', 'contacto8@example.com'),
(9, 'Propietario 9', 'contacto9@example.com'),
(10, 'Propietario 10', 'contacto10@example.com'),
(11, 'Propietario 11', 'contacto11@example.com'),
(12, 'Propietario 12', 'contacto12@example.com'),
(13, 'Propietario 13', 'contacto13@example.com'),
(14, 'Propietario 14', 'contacto14@example.com'),
(15, 'Propietario 15', 'contacto15@example.com'),
(16, 'Propietario 16', 'contacto16@example.com'),
(17, 'Propietario 17', 'contacto17@example.com'),
(18, 'Propietario 18', 'contacto18@example.com'),
(19, 'Propietario 19', 'contacto19@example.com'),
(20, 'Propietario 20', 'contacto20@example.com'),
(21, 'Propietario 21', 'contacto21@example.com'),
(22, 'Propietario 22', 'contacto22@example.com'),
(23, 'Propietario 23', 'contacto23@example.com'),
(24, 'Propietario 24', 'contacto24@example.com'),
(25, 'Propietario 25', 'contacto25@example.com'),
(26, 'Propietario 26', 'contacto26@example.com'),
(27, 'Propietario 27', 'contacto27@example.com'),
(28, 'Propietario 28', 'contacto28@example.com'),
(29, 'Propietario 29', 'contacto29@example.com'),
(30, 'Propietario 30', 'contacto30@example.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `viviendas`
--

CREATE TABLE `viviendas` (
  `id` int(11) NOT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `metros_cuadrados` int(11) DEFAULT NULL,
  `cantidad_habitaciones` int(11) DEFAULT NULL,
  `fecha_construccion` date DEFAULT NULL,
  `amueblada` tinyint(1) DEFAULT NULL,
  `propietario_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `viviendas`
--

INSERT INTO `viviendas` (`id`, `precio`, `metros_cuadrados`, `cantidad_habitaciones`, `fecha_construccion`, `amueblada`, `propietario_id`) VALUES
(121, 120000.50, 85, 3, '2010-05-15', 1, 1),
(122, 95000.00, 60, 2, '2005-10-20', 0, 4),
(123, 150000.00, 100, 4, '2018-07-30', 1, 3),
(124, 80000.00, 55, 2, '2001-04-12', 0, 21),
(125, 200000.00, 120, 5, '2020-01-25', 1, 11),
(126, 175000.00, 110, 4, '2015-09-10', 1, 4),
(127, 90000.00, 70, 3, '2007-12-01', 0, 12),
(128, 220000.00, 130, 5, '2019-11-17', 1, 1),
(129, 100000.00, 75, 3, '2012-03-19', 1, 23),
(130, 160000.00, 95, 4, '2016-06-21', 0, 4),
(131, 140000.00, 85, 3, '2013-08-14', 1, 26),
(132, 110000.00, 65, 2, '2009-02-25', 0, 12),
(133, 95000.00, 60, 2, '2006-11-29', 1, 13),
(134, 190000.00, 105, 4, '2017-04-13', 0, 14),
(135, 210000.00, 125, 5, '2021-02-02', 1, 15),
(136, 85000.00, 55, 2, '2004-06-11', 0, 16),
(137, 170000.00, 115, 4, '2014-05-24', 1, 17),
(138, 130000.00, 80, 3, '0000-00-00', 1, 18),
(139, 155000.00, 90, 3, '2015-01-18', 0, 19),
(140, 120000.00, 75, 3, '2013-03-25', 1, 20),
(141, 140000.00, 85, 3, '2012-09-16', 0, 21),
(142, 115000.00, 65, 2, '2008-12-05', 1, 22),
(143, 175000.00, 110, 4, '2016-11-30', 0, 23),
(144, 200000.00, 120, 5, '2019-07-28', 1, 24),
(145, 90000.00, 70, 3, '2007-05-14', 0, 25),
(146, 125000.00, 80, 3, '2010-08-03', 1, 24),
(147, 180000.00, 115, 4, '2015-12-22', 1, 27),
(148, 85000.00, 55, 2, '2003-04-07', 0, 28),
(149, 220000.00, 130, 5, '2020-09-12', 1, 29),
(150, 105000.00, 65, 2, '2011-10-30', 0, 30);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `propietarios`
--
ALTER TABLE `propietarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `viviendas`
--
ALTER TABLE `viviendas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `propietario_id` (`propietario_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `propietarios`
--
ALTER TABLE `propietarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de la tabla `viviendas`
--
ALTER TABLE `viviendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `viviendas`
--
ALTER TABLE `viviendas`
  ADD CONSTRAINT `viviendas_ibfk_1` FOREIGN KEY (`propietario_id`) REFERENCES `propietarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
