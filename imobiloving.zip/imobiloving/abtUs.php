<?php include("template/headr.php");?>

<div class="jumbotron">
    <h1 class="display-3">Esta página fue hecha por:</h1>
    <p class="lead">Nikolas Jaimes</p>
    <hr class="my-2">
  
</div>

<div class="text-box">
    <h2>¿Que es Inmobiloving?</h2>
    <p>Es el proyecto final que elegi para el curso de HTML, JavaScipt, SQL y PHP</p>
    <p>de Dusto formación. Esta página fue diseñada con propositos educaticos</p>
</div>

<?php include("template/footr.php");?>