        
            </div>
        </div>
    </div>
    
    <<ul class="list-group">
        <li class="list-group-item active"><a href="abtUs.php" title="sobre nosotros">¿Que es Inmobiloving?</a></li>
        <li class="list-group-item">Item</li>
        <li class="list-group-item disabled">Disabled item</li>
    </ul>

    <script src="scripts/filtro.js"></script>



</body>
</html>