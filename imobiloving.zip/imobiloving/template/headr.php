<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>InmobiLoving</title>

    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <ul class="nav navbar-nav">
               
            <li class="nav-item">
                <a class="nav-link" href="index.php">InmobiLoving</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="vivend.php">Nuestras Viviendas</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="abtUs.php">Sobre Nosotros</a>
            </li>

        </ul>
    </nav>

    <div class="container">
        <div class="row">