$(document).ready(function(){
    $("#search").click(function(){
        var formData = {
            precio: $("input[name='precio']:checked").val(),
            habitaciones: $("input[name='habitaciones[]']:checked").map(function(){ return this.value; }).get(),
            metros: $("input[name='metros']:checked").val(),
            fecha_construccion: $("#dateBuild").val()
        };

        $.ajax({
            type: "POST",
            url: "buscar.php",
            data: formData,
            dataType: "json",
            success: function(response){
                var resultados = $("#resultados");
                resultados.empty();
                if(response.length > 0) {
                    $.each(response, function(index, vivienda){
                        resultados.append(
                            `<p>Precio: ${vivienda.precio} € - Metros Cuadrados: ${vivienda.metros_cuadrados} m² - Habitaciones: ${vivienda.habitaciones} - Fecha de Construcción: ${vivienda.fecha_construccion} - Amueblada: ${vivienda.amueblada ? 'Sí' : 'No'} - Contacto: ${vivienda.contacto}</p>`
                        );
                    });
                } else {
                    resultados.append("<p>No se encontraron resultados</p>");
                }
            }
        });
    });
});

$(document).ready(function(){
    $('#clearBtn').click(function(){

        $('#formu')[0].reset(); //resetear formulario

        $('#resultados').html("<p>No se encontraron resultados</p>"); //limpiar los resultados

    })
})