<?php include("template/headr.php");?>

<div class="col-md-4">

<div class="jumbotron jumbotron-fluid">
        <div class="container">

            <h1 class="display-3">¡Encuentra tu piso ideal!</h1>
            <p class="lead">Solo pulsa abajo para empezar tu busqueda</p>
            <hr class="my-2">
            
            <p class="lead">
                <a class="btn btn-primary btn-lg" href="pisos.php" role="button">Buscar Pisos</a>
            </p>

        </div>
    </div>

    <div>
        <img src="https://img.freepik.com/foto-gratis/concepto-marketing-redes-sociales-marketing-aplicaciones_23-2150063170.jpg?size=626&ext=jpg&ga=GA1.1.2008272138.1721088000&semt=ais_user" width="330px">
    </div>
    
</div>

<div class="col-md-8">

    <div class="card">
        <img class="card-img-top" src="https://luxuryrentalsmadrid.com/storage/app/uploads/public/643/826/c72/643826c723dc0574532299.jpg" alt="">
        <div class="card-body">
            <h4 class="card-title">Conoce nuestra variedad de pisos</h4>
            <p class="card-text">Diferentes pisos en las mejores zonas del país, una variedad excelente de precios asequibles,
                diferentes estilos de pisos de todas las epocas, tamaños y cantidad de habitaciones.

                Todo esto y mucho más a tu disposición en Inmobiloving.
            </p>
        </div>
    </div>

    
</div>


    


<?php include("template/footr.php");?>