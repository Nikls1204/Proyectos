<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inmobiliaria";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$precio = isset($_POST['precio']) ? $_POST['precio'] : '';
$habitaciones = isset($_POST['habitaciones']) ? $_POST['habitaciones'] : [];
$metros = isset($_POST['metros']) ? $_POST['metros'] : '';
$fecha_construccion = isset($_POST['fecha_construccion']) ? $_POST['fecha_construccion'] : '';

$sql = "SELECT * FROM viviendas WHERE 1=1";

if($precio) {
    $rangos = explode('-', $precio);
    $sql .= " AND precio BETWEEN {$rangos[0]} AND {$rangos[1]}";
}

if($habitaciones) {
    $habitaciones_list = implode(",", $habitaciones);
    $sql .= " AND habitaciones IN ({$habitaciones_list})";
}

if($metros) {
    $rangos = explode('-', $metros);
    $sql .= " AND metros_cuadrados BETWEEN {$rangos[0]} AND {$rangos[1]}";
}

if($fecha_construccion) {
    $sql .= " AND fecha_construccion >= '{$fecha_construccion}'";
}

$result = $conn->query($sql);
$viviendas = [];

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $viviendas[] = $row;
    }
}

$conn->close();
echo json_encode($viviendas);


