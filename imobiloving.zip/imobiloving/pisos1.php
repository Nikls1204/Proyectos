<?php include("template/headr.php");?>



<div class="col-md-2">

<h3>Precio</h3>

<div class="form-check">
    <label class="form-check-label">
    <input type="radio" class="form-check-input" name="precio" id="low" value="checked">
    70000 - 100000 €
  </label>
</div>


<div class="form-check">
    <label class="form-check-label">
    <input type="radio" class="form-check-input" name="precio" id="mid" value="checked">
    110000 - 114000 €
  </label>
</div>

<div class="form-check">
    <label class="form-check-label">
    <input type="radio" class="form-check-input" name="precio" id="high" value="checked">
    115000 - 119000 €
  </label>
</div>

<hr class="my-3">

<h3>Habitaciones</h3>


<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="2" id="dos" value="checkedValue">
    2
  </label>
</div>

<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="3" id="tres" value="checkedValue">
    3
  </label>
</div>

<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="4" id="cuatro" value="checkedValue">
    4
  </label>
</div>

<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="5" id="cinco" value="checkedValue">
    5
  </label>
</div>
    
</div>

<div class="col-md-3">

    <h3>Metros Cuadrados</h3>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metro" id="low1" value="checkedValue" >
        50 - 60
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metro" id="low2" value="checkedValue" >
        70 - 80
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metro" id="mid1" value="checkedValue" >
        90 - 100
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metro" id="mid2" value="checkedValue" >
        110 - 120
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metro" id="high1" value="checkedValue" >
        120 - 130
      </label>
    </div>

    <hr class="my-3">

    <h3>Fecha de construcción</h3>

    <div class="form-group">
      <label for="Fecha"></label>
      <input type="date"
        class="form-control" name="fecha construcción" id="dateBuild" aria-describedby="helpId" placeholder="">
    </div>
    
</div>

<div class="col-md-7">

    <div class="card">
        <img class="card-img-top" src="holder.js/100x180/" alt="">
        <div class="card-body">
            <h4 class="card-title">Title</h4>
            <p class="card-text">Text</p>
        </div>
    </div>

</div>

<hr class="my-4">

<input name="Buscar" id="search" class="btn btn-primary" type="button" value="Buscar">


<?php include("template/footr.php");?>