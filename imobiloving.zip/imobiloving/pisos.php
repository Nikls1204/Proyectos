<?php include("template/headr.php");
include("sql/connect.php");

?>

<?php 
    //ver errores
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    $precio = isset($_POST['precio']) ? $_POST['precio'] : '';
    $habitaciones = isset($_POST['cantidad_habitaciones']) ? $_POST['cantidad_habitaciones'] : [];
    $metros = isset($_POST['metros']) ? $_POST['metros'] : '';
    $fecha_construccion = isset($_POST['fecha_construccion']) ? $_POST['fecha_construccion'] : '';

    $sql = "SELECT * FROM viviendas WHERE 1=1";

    if($precio){
        $rangos = explode('-', $precio);
        if(isset($rangos[0]) && isset($rangos[1])){
            $sql .= " AND precio BETWEEN {$rangos[0]} AND {$rangos[1]}";
        }
    }

    if(!empty($habitaciones)){
        $habitaciones = array_map('intval', $habitaciones);
        $habitaciones_list = implode(",", $habitaciones);
        $sql .= " AND habitaciones IN ({$habitaciones_list})";
    }

    if($metros){
        $rangos = explode('-', $metros);
        if(isset($rangos[0]) && isset($rangos[1])){
            $sql .= " AND metros_cuadrados BETWEEN {$rangos[0]} AND {$rangos[1]}";
        }
       
    }

    if($fecha_construccion){
        $sql .= " AND fecha_construccion >= '{$fecha_construccion}'";
    }

    //Ejecutar query de SQL

    $result = null;
    if($_SERVER['REQUEST_METHOD']== 'POST'){
        $result = $conn->query($sql);
    }

    $conn->close();

?>

<div class="col-md-2">
<form id="formu" method="post" action="">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<h3>Precio</h3>

<div class="form-check">
    <label class="form-check-label">
    <input type="radio" class="form-check-input" name="precio" id="low" value="70000-100000">
    70000 - 100000 €
  </label>
</div>


<div class="form-check">
    <label class="form-check-label">
    <input type="radio" class="form-check-input" name="precio" id="mid" value="110000-114000">
    110000 - 114000 €
  </label>
</div>

<div class="form-check">
    <label class="form-check-label">
    <input type="radio" class="form-check-input" name="precio" id="high" value="115000-119000">
    115000 - 119000 €
  </label>
</div>

<hr class="my-3">

<h3>Habitaciones</h3>


<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="habitaciones[]" id="dos" value="2">
    2
  </label>
</div>

<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="habitaciones[]" id="tres" value="3">
    3
  </label>
</div>

<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="habitaciones[]" id="cuatro" value="4">
    4
  </label>
</div>

<div class="form-check">
  <label class="form-check-label">
    <input type="checkbox" class="form-check-input" name="habitaciones[]" id="cinco" value="5">
    5
  </label>
</div>
    
</div>

<div class="col-md-3">

    <h3>Metros Cuadrados</h3>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metro" id="low1" value="checkedValue" >
        50 - 60
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metros" id="low2" value="checkedValue" >
        70 - 80
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metros" id="mid1" value="checkedValue" >
        90 - 100
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metros" id="mid2" value="checkedValue" >
        110 - 120
      </label>
    </div>

    <div class="form-check">
        <label class="form-check-label">
        <input type="radio" class="form-check-input" name="metros" id="high1" value="checkedValue" >
        120 - 130
      </label>
    </div>

    <hr class="my-3">

    <h3>Fecha de construcción</h3>

    <div class="form-group">
      <label for="Fecha"></label>
      <input type="date"
        class="form-control" name="fecha construcción" id="dateBuild" aria-describedby="helpId" placeholder="">
    </div>

    <div class="row">
    <hr class="my-4">

    <input name="Buscar" id="search" class="btn btn-primary" type="submit" value="Buscar">

    </div>
    

    
</div>

<div class="col-md-7">

    <div class="card card-scrollable">
        <div class="card-body">
            <h4 class="card-title">Resultados de la busqueda</h4>
            <div id="resultados">


            <?php 
            
            if($result && $result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    echo "<div class='card'>";
                    echo "<div class='card-body'>";
                    echo "<h5 class='card-title'>Precio: {$row['precio']} €</h5>";
                    echo "<p class='card-text'>Metros Cuadrados: {$row['metros_cuadrados']} m²</p>";
                    echo "<p class='card-text'>Habitaciones: {$row['cantidad_habitaciones']}</p>";
                    echo "<p class='card-text'>Fecha de Construcción: {$row['fecha_construccion']}</p>";
                    echo "<p class='card-text'>Amueblada ". ($row['amueblada']? 'Si' : 'No') . "</p>";
                    echo "<p class='card-text'>Contacto:". (isset($row['contacto']) ? $row['contacto'] : 'No disponible') . "</p>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p>No se encontraron resultados</p>";
            }

            ?>

            </div>
        </div>
        <button type="button" id="clearBtn" class="btn btn-secondary">Limpiar</button>
    </div>
    

</div>





</form>




<?php include("template/footr.php");?>