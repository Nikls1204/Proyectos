<?php include("template/headr.php");?>

<link rel="stylesheet" href="./css/styles.css">

<div class="col-md-7">

<div class="jumbotron">
                <h1 class="display-3">Bienvenido a InmobiLoving</h1>
                <img class="card-img-top" src="img/logo.png" style="width: 500px; flex: auto">
            

            </div>

            
</div>

<div class="col-md-4">
    <div id="bloqueTxt" class="fade-in-text">
             <p>Los mejores pisos en los mejores lugares,</p>
             <P>y todo al alcance de tus manos en Inmobiloving</P>
             <img src="img/42856041.jpg" width="480px">
             
    
             <p>Página web con propositos educativos</p>



    </div>
</div>

<style>
    .fade-in-text{
    padding-top: 80px;
    opacity: 0;
    animation:fadeIn 2s forwards;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

</style>
            
<?php include("template/footr.php");?>
   